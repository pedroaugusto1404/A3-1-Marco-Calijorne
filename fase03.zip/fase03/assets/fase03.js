var imagens = ["./assets/img/foto 01.png", "./assets/img/foto 02.png", "./assets/img/foto 03.png"];
var indiceAtual = 0;

function mudarImagem() {
  var img = document.getElementById("imagem");
  indiceAtual = (indiceAtual + 1) % imagens.length;
  img.src = imagens[indiceAtual];
}



  

function validarCPF() {
    const cpfInput = document.getElementById('cpf').value;
    const cpfPattern = /^\d{3}\.\d{3}\.\d{3}-\d{2}$/;
  
    if (cpfPattern.test(cpfInput)) {
      exibirResultado('cpfResult', 'CPF válido');
    } else {
      exibirResultado('cpfResult', 'CPF inválido');
    }
  }
  
  function validarEmail() {
    const emailInput = document.getElementById('email').value;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
    if (emailPattern.test(emailInput)) {
      exibirResultado('emailResult', 'E-mail válido');
    } else {
      exibirResultado('emailResult', 'E-mail inválido');
    }
  }
  
  function exibirResultado(id, mensagem) {
    document.getElementById(id).textContent = mensagem;
  }
  
  function adicionarItem() {
    var novoItem = prompt("Digite o novo item:");
    if (novoItem) {
      var lista = document.getElementById("listaItens");
      var novoElemento = document.createElement("li");
      novoElemento.textContent = novoItem;
      lista.insertBefore(novoElemento, lista.lastElementChild);
    }
  }

  function adicionarItem() {
    var novoItem = prompt("Digite o novo item:");
    if (novoItem) {
      var lista = document.getElementById("listaItens");
      var novoElemento = document.createElement("li");
      novoElemento.textContent = novoItem + " ";
      var botaoRemover = document.createElement("button");
      botaoRemover.textContent = "Remover";
      botaoRemover.onclick = function() {
        removerItem(this);
      };
      novoElemento.appendChild(botaoRemover);
      lista.insertBefore(novoElemento, lista.lastElementChild);
    }
  }
  
  function removerItens() {
    var lista = document.getElementById("listaItens");
    var checkboxes = lista.querySelectorAll("input[type='checkbox']");
    for (var i = 0; i < checkboxes.length; i++) {
      if (checkboxes[i].checked) {
        var item = checkboxes[i].parentNode;
        lista.removeChild(item);
      }
    }
  }
  
  

  
  
  