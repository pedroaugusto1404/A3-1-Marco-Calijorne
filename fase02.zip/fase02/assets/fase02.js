var imagens = ["./assets/img/foto 01.png", "./assets/img/foto 02.png", "./assets/img/foto 03.png"];
var indiceAtual = 0;

function mudarImagem() {
  var img = document.getElementById("imagem");
  indiceAtual = (indiceAtual + 1) % imagens.length;
  img.src = imagens[indiceAtual];
}